# ETF RADAR 67 — Phase 01 MVP

台股 ETF 三個月低點監控 PWA 原型，採專業金融終端機深色介面。

## 本階段已完成

- iPhone / 桌面自適應介面
- PWA manifest 與 service worker（可加入主畫面、基本離線快取）
- CSV 行情匯入、資料合併及本機保存
- 盤中低點與收盤低點分開計算
- ETF 清單、資料完整度、低點事件表及代號搜尋
- 支援民國日期與西元日期
- 支援常見中英文欄位名稱

## 尚未完成（不可視為已上線）

- 自動下載 TWSE / TPEx 全部 ETF 日行情
- 盤中即時行情串流與每分鐘監控
- 雲端資料庫、排程工作與推播伺服器
- iPhone Web Push 設定與通知權限流程
- 歷史回測及基本面分析

## 啟動方式

本專案是靜態 PWA。可使用任何靜態網站主機；本機測試可在專案目錄執行：

```bash
python -m http.server 8000
```

再用瀏覽器開啟 `http://localhost:8000`。PWA 安裝及 Service Worker 通常需要 HTTPS（localhost 除外）。

## CSV 匯入格式

必要欄位：`代號,日期,最低價,收盤價`  
建議欄位：`名稱,開盤價,最高價,成交量`

範本可在 App 內按「下載 CSV 範本」取得。可匯入多份 CSV，程式以「代號＋日期」合併。

### 低點定義

對每檔 ETF 的最新資料日：

- 盤中低點：最新日 `low` 嚴格小於此前三個日曆月（不含當日）所有有效日 `low` 的最低值。
- 收盤低點：最新日 `close` 嚴格小於此前三個日曆月（不含當日）所有有效日 `close` 的最低值。

資料不足三個月者不產生警報，並在監控清單標示「不足 / 待補」。

## 官方資料入口

- TWSE ETF 每日行情：<https://www.twse.com.tw/en/products/securities/etf/trading/statistics/day.html>
- TPEx ETF 歷史行情：<https://www.tpex.org.tw/zh-tw/product/etf/info/historical/day.html>
- TWSE OpenAPI 文件：<https://openapi.twse.com.tw/>

目前官方頁面提供行情查詢與下載入口；本版先以 CSV 匯入驗證欄位及計算邏輯，避免未驗證的端點造成錯誤警報。後續需針對官方下載格式及使用條款完成適配器，再啟用自動同步。

## 重要說明

- 本版匯入的是日行情，因此「盤中低點」是當日已完成日行情中的最低價，不是盤中即時偵測。
- 本版不會自動發送推播。
- 本機資料儲存在目前瀏覽器的 localStorage；清除瀏覽器資料可能使資料消失。正式版應改用雲端資料庫及備份。
- 本工具僅整理市場資料，不構成投資建議。
