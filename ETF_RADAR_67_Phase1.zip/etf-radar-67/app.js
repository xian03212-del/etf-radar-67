const STORAGE_KEY = "etf-radar-67-records-v1";
let records = [];
let currentFilter = "all";

const $ = (id) => document.getElementById(id);
const aliases = {
  code: ["code","代號","證券代號","股票代號","基金代碼","symbol","ticker"],
  name: ["name","名稱","證券名稱","基金名稱","商品名稱"],
  date: ["date","日期","資料日期","交易日期","年月日","交易日"],
  open: ["open","開盤價","開盤","opening price"],
  high: ["high","最高價","最高","highest price"],
  low: ["low","最低價","最低","最低成交價","lowest price"],
  close: ["close","收盤價","收盤","closing price"],
  volume: ["volume","成交量","成交股數","成交單位","trading volume"]
};

function normalizeHeader(s) {
  return String(s ?? "").replace(/^\uFEFF/,"").trim().toLowerCase().replace(/[\s_\-（）()]/g,"");
}
function parseNumber(v) {
  if (v == null) return null;
  const s = String(v).replace(/,/g,"").replace(/－/g,"-").trim();
  if (!s || s === "--" || s === "-" || s === "X") return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}
function parseDate(v) {
  const s = String(v ?? "").trim().replace(/[年./]/g,"-").replace(/月/g,"-").replace(/日/g,"");
  let m = s.match(/^(\d{3})-?(\d{1,2})-?(\d{1,2})$/);
  if (m) return `${Number(m[1])+1911}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
  m = s.match(/^(\d{4})-?(\d{2})-?(\d{2})$/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  return "";
}
function splitCSV(text) {
  const rows=[]; let row=[], cell="", quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i], next=text[i+1];
    if(c === '"' && quoted && next === '"'){cell+='"';i++;}
    else if(c === '"'){quoted=!quoted;}
    else if(c === "," && !quoted){row.push(cell);cell="";}
    else if((c === "\n" || c === "\r") && !quoted){
      if(c === "\r" && next === "\n") i++;
      row.push(cell); if(row.some(x=>String(x).trim()!=="")) rows.push(row);
      row=[];cell="";
    } else cell+=c;
  }
  row.push(cell); if(row.some(x=>String(x).trim()!=="")) rows.push(row);
  return rows;
}
function findColumn(headers, key) {
  const normalized=headers.map(normalizeHeader);
  for(const a of aliases[key]){
    const idx=normalized.indexOf(normalizeHeader(a));
    if(idx>=0) return idx;
  }
  return -1;
}
function parseCSV(text) {
  const rows=splitCSV(text);
  if(rows.length<2) throw new Error("CSV 沒有可讀取的資料列。");
  const headers=rows[0];
  const cols={}; for(const key of Object.keys(aliases)) cols[key]=findColumn(headers,key);
  const required=["code","date","low","close"];
  const missing=required.filter(k=>cols[k]<0);
  if(missing.length) throw new Error(`缺少必要欄位：${missing.map(k=>aliases[k][0]).join("、")}。請先下載範本並整理欄位。`);
  const out=[];
  for(let i=1;i<rows.length;i++){
    const r=rows[i], get=k=>cols[k]>=0?r[cols[k]]:"";
    const code=String(get("code")).trim().replace(/^'/,"");
    const date=parseDate(get("date"));
    const low=parseNumber(get("low")), close=parseNumber(get("close"));
    if(!code || !date || low==null || close==null) continue;
    out.push({code,name:String(get("name")||"").trim(),date,open:parseNumber(get("open")),high:parseNumber(get("high")),low,close,volume:parseNumber(get("volume"))});
  }
  if(!out.length) throw new Error("沒有找到有效行情列。請確認日期、代號、最低價及收盤價欄位。");
  return out;
}
function mergeRecords(incoming) {
  const map=new Map(records.map(r=>[`${r.code}|${r.date}`,r]));
  for(const r of incoming) map.set(`${r.code}|${r.date}`,{...map.get(`${r.code}|${r.date}`),...r});
  records=[...map.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.code.localeCompare(b.code));
  localStorage.setItem(STORAGE_KEY,JSON.stringify(records));
}
function dateMinusMonths(dateStr, months=3) {
  const d=new Date(`${dateStr}T12:00:00`);
  const originalDay=d.getDate();
  d.setMonth(d.getMonth()-months);
  if(d.getDate()!==originalDay) d.setDate(0);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function analyze() {
  const byCode=new Map();
  for(const r of records){if(!byCode.has(r.code))byCode.set(r.code,[]);byCode.get(r.code).push(r);}
  const universe=[], alerts=[];
  let qualified=0;
  for(const [code,arr] of byCode){
    arr.sort((a,b)=>a.date.localeCompare(b.date));
    const latest=arr[arr.length-1], cutoff=dateMinusMonths(latest.date,3);
    const prior=arr.filter(r=>r.date>=cutoff && r.date<latest.date);
    const hasHistory=prior.length>0 && prior[0].date<=cutoff;
    if(hasHistory) qualified++;
    universe.push({...latest,historyCount:prior.length,hasHistory});
    if(!hasHistory) continue;
    const priorLow=prior.reduce((best,r)=>r.low<best.value?{value:r.low,date:r.date}:best,{value:Infinity,date:""});
    const priorClose=prior.reduce((best,r)=>r.close<best.value?{value:r.close,date:r.date}:best,{value:Infinity,date:""});
    if(latest.low<priorLow.value){
      alerts.push({code,name:latest.name||code,type:"intraday",date:latest.date,price:latest.low,reference:priorLow.value,referenceDate:priorLow.date,volume:latest.volume});
    }
    if(latest.close<priorClose.value){
      alerts.push({code,name:latest.name||code,type:"close",date:latest.date,price:latest.close,reference:priorClose.value,referenceDate:priorClose.date,volume:latest.volume});
    }
  }
  alerts.sort((a,b)=>b.date.localeCompare(a.date)||a.code.localeCompare(b.code));
  universe.sort((a,b)=>a.code.localeCompare(b.code));
  return {universe,alerts,qualified,total:byCode.size};
}
function fmt(n){return n==null?"—":Number(n).toLocaleString("zh-TW",{minimumFractionDigits:2,maximumFractionDigits:4});}
function pct(a,b){return b>0?((a-b)/b*100):0;}
function render(){
  const {universe,alerts,qualified,total}=analyze();
  const latestDate=records.length?records.reduce((m,r)=>r.date>m?r.date:m,""):"";
  $("latestDate").textContent=latestDate||"尚無資料";
  $("recordCount").textContent=records.length.toLocaleString("zh-TW");
  $("etfCount").textContent=total.toLocaleString("zh-TW");
  $("intradayCount").textContent=alerts.filter(a=>a.type==="intraday").length;
  $("closeCount").textContent=alerts.filter(a=>a.type==="close").length;
  $("coverage").textContent=total?`${Math.round(qualified/total*100)}%`:"0%";
  $("systemStatus").textContent=records.length?`已載入 ${total} 檔 ETF`:"等待匯入行情";
  const filtered=alerts.filter(a=>currentFilter==="all"||a.type===currentFilter);
  $("alertsBody").innerHTML=filtered.length?filtered.map(a=>{
    const drop=Math.abs(pct(a.price,a.reference));
    return `<tr><td><div class="symbol">${esc(a.code)}</div><div class="subname">${esc(a.name)}</div></td><td><span class="event-pill ${a.type}">${a.type==="intraday"?"盤中低點":"收盤低點"}</span></td><td>${a.date}</td><td class="positive">${fmt(a.price)}</td><td>${fmt(a.reference)} <span class="subname">(${a.referenceDate})</span></td><td class="positive">${drop.toFixed(2)}%</td></tr>`;
  }).join(""):`<tr><td colspan="6" class="empty">${records.length?"目前沒有符合條件的新低事件。":"匯入行情資料後，這裡會顯示符合條件的新低事件。"}</td></tr>`;
  const q=$("searchInput").value.trim().toLowerCase();
  const visible=universe.filter(r=>!q||r.code.toLowerCase().includes(q)||(r.name||"").toLowerCase().includes(q));
  $("universeBody").innerHTML=visible.length?visible.map(r=>`<tr><td class="symbol">${esc(r.code)}</td><td>${esc(r.name||"—")}</td><td>${r.date}</td><td>${fmt(r.low)}</td><td>${fmt(r.close)}</td><td class="${r.hasHistory?"coverage-good":"coverage-low"}">${r.hasHistory?"足夠":"不足 / 待補"} <span class="subname">(${r.historyCount} 筆比較資料)</span></td></tr>`).join(""):`<tr><td colspan="6" class="empty">找不到符合的 ETF。</td></tr>`;
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function downloadTemplate(){
  const csv="代號,名稱,日期,開盤價,最高價,最低價,收盤價,成交量\n0050,元大台灣50,2026-08-03,100.00,101.00,99.50,100.50,123456\n";
  const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="etf-radar-67-template.csv";a.click();URL.revokeObjectURL(url);
}
$("csvInput").addEventListener("change",async e=>{
  const file=e.target.files?.[0]; if(!file)return;
  try{
    const parsed=parseCSV(await file.text()); mergeRecords(parsed);
    $("importMessage").className="import-message success";
    $("importMessage").textContent=`成功匯入 ${parsed.length.toLocaleString("zh-TW")} 筆資料；目前累計 ${records.length.toLocaleString("zh-TW")} 筆。請確認每檔 ETF 都有完整三個月歷史資料。`;
    render();
  }catch(err){$("importMessage").className="import-message error";$("importMessage").textContent=err.message;}
  e.target.value="";
});
$("templateBtn").addEventListener("click",downloadTemplate);
$("clearBtn").addEventListener("click",()=>{
  if(!confirm("確定清除這台裝置儲存的所有 ETF 行情資料？"))return;
  records=[];localStorage.removeItem(STORAGE_KEY);
  $("importMessage").className="import-message";$("importMessage").textContent="本機資料已清除。";render();
});
$("searchInput").addEventListener("input",render);
document.querySelectorAll(".segment").forEach(btn=>btn.addEventListener("click",()=>{
  currentFilter=btn.dataset.filter;
  document.querySelectorAll(".segment").forEach(x=>x.classList.toggle("active",x===btn));
  render();
}));
try{records=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");}catch{records=[];}
render();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
